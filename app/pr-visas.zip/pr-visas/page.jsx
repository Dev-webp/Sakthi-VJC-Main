

import Two from "./Two";
// import Footer from "./Footer";

const ContactPage = () => {
  return (
    <>
      <div style={{ marginTop: "5%", zIndex: 20, position: "relative" }}>
        {/* <Nav /> */}
      </div>
      <Two />
 
    </>
  );
};

export default ContactPage;
